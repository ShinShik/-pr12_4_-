using System.Diagnostics.Metrics;
using System.Windows.Forms;

namespace Работа_12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public double price = 0;
        public double price_ALL = 0;
        public double sale = 0;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void labelHeight_Click(object sender, EventArgs e)
        {

        }

        private void comboBoxName_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxColor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxCountry_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDownHeight_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDownQuantity_ValueChanged(object sender, EventArgs e)
        {

        }

        private void buttonWritePurshase_Click(object sender, EventArgs e)
        {
            if (listBoxFlowers.Items.Count == 10)
            {
                MessageBox.Show("Корзина заполнена");
            }
            else
            {
                try
                {
                    if (comboBoxName.Text != "" &&
                        comboBoxType.Text != "" &&
                        comboBoxColor.Text != "" &&
                        comboBoxCountry.Text != "")
                    {
                        Flowers flower = new Flowers
                        (
                        comboBoxName.Text,
                        comboBoxType.Text,
                        comboBoxColor.Text,
                        comboBoxCountry.Text,
                        (int)numericUpDownHeight.Value,
                        (int)numericUpDownQuantity.Value
                    );
                        listBoxFlowers.Items.Add(flower.Print_info());
                        price = flower.Price_calculation();
                        sale = flower.SALE();
                        if (sale == 1.0)
                        {
                            MessageBox.Show($"Стоимость данной покупки {price}");
                            price_ALL += price;
                        }
                        else
                        {
                            MessageBox.Show($"Стоимость данной покупки с скидкой {price * sale}");
                            price_ALL += price * sale;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Вы не заполнили поля");
                    }

                }
                catch
                {
                    MessageBox.Show("Ошибка");
                }
            }

        }

        private void buttonCheckPrice_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"На данный момент общая стоимость корзины составляет {price_ALL}");
        }

        private void buttonClearList_Click(object sender, EventArgs e)
        {
            listBoxFlowers.Items.Clear();
            price = 0;
        }

        private void listBoxFlowers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
