﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Работа_12
{
    
    internal class Flowers
    {
        Random rnd = new Random();
        string Name {  get; set; }
        string Type {  get; set; }
        string Color { get; set; }
        string Country { get; set; }
        double Price { get; set; }
        public int Height { get; set; }
        public int Quantity { get; set; }
        private double Sale = 0.0;

        public Flowers(string name, string type, string color, string country, int height, int quantity)
        {
            Name = name;
            Type = type;
            Color = color;
            Country = country;
            Height = height;
            Quantity = quantity;
        }
        public string Print_info()
        {
            Price_calculation();
            return $"{Color} {Type} {Name} из страны {Country} длинной {Height} ( {Quantity} штук )";
        }
        public double Price_calculation()
        {
            double price = 10;
            switch (Name)
            {
                case "Розы":
                    price *= 2;
                    break;
                case "Кактусы":
                    price *= 3;
                    break;
                case "Архидеи":
                    price *= 4;
                    break;
                case "Подсолнухи":
                    price *= 5;
                    break;
                default:
                    price *= 10;
                    break;
            }
            switch (Type)
            {
                case "обычные":
                    price *= 1;
                    break;
                case "необычные":
                    price *= 2;
                    break;
                case "необычнообычные":
                    price *= 3;
                    break;
                default:
                    price *= 4;
                    break;
            }
            switch (Color)
            {
                case "красные":
                    price *= 2;
                    break;
                case "зелёные":
                    price *= 3;
                    break;
                case "фиолетовый":
                    price *= 4;
                    break;
                case "аделаидные":
                    price *= 5;
                    break;
                default:
                    price *= 6;
                    break;
            }
            switch (Country)
            {
                case "Россия":
                    price *= 2;
                    break;
                case "Китай":
                    price *= 3;
                    break;
                case "США":
                    price *= 4;
                    break;
                case "Канада":
                    price *= 5;
                    break;
                default:
                    price *= 6;
                    break;
            }
            price = (price + Height) * Quantity;
            Price = price;
            return price;
        }
        public double SALE()
        {
            if (rnd.Next(1, 5 + 1) == 1)
            {
                return 0.5;
            }
            else return 1.0;
        }
    }
}
