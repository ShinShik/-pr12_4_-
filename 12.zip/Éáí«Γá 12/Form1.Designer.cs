﻿namespace Работа_12
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            labelName = new Label();
            labelType = new Label();
            labelColor = new Label();
            labelCountry = new Label();
            labelHeight = new Label();
            comboBoxName = new ComboBox();
            comboBoxType = new ComboBox();
            comboBoxCountry = new ComboBox();
            comboBoxColor = new ComboBox();
            listBoxFlowers = new ListBox();
            labelQuantity = new Label();
            buttonCheckPrice = new Button();
            buttonClearList = new Button();
            buttonWritePurshase = new Button();
            numericUpDownHeight = new NumericUpDown();
            numericUpDownQuantity = new NumericUpDown();
            contextMenuStrip1 = new ContextMenuStrip(components);
            ((System.ComponentModel.ISupportInitialize)numericUpDownHeight).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownQuantity).BeginInit();
            SuspendLayout();
            // 
            // labelName
            // 
            labelName.AutoSize = true;
            labelName.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelName.Location = new Point(23, 38);
            labelName.Name = "labelName";
            labelName.Size = new Size(137, 21);
            labelName.TabIndex = 0;
            labelName.Text = "Название цветка";
            // 
            // labelType
            // 
            labelType.AutoSize = true;
            labelType.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelType.Location = new Point(23, 69);
            labelType.Name = "labelType";
            labelType.Size = new Size(92, 21);
            labelType.TabIndex = 1;
            labelType.Text = "Тип цветка";
            // 
            // labelColor
            // 
            labelColor.AutoSize = true;
            labelColor.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelColor.Location = new Point(23, 102);
            labelColor.Name = "labelColor";
            labelColor.Size = new Size(102, 21);
            labelColor.TabIndex = 2;
            labelColor.Text = "Цвет цветка";
            // 
            // labelCountry
            // 
            labelCountry.AutoSize = true;
            labelCountry.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelCountry.Location = new Point(23, 133);
            labelCountry.Name = "labelCountry";
            labelCountry.Size = new Size(117, 21);
            labelCountry.TabIndex = 3;
            labelCountry.Text = "Страна цветка";
            // 
            // labelHeight
            // 
            labelHeight.AutoSize = true;
            labelHeight.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelHeight.Location = new Point(24, 161);
            labelHeight.Name = "labelHeight";
            labelHeight.Size = new Size(122, 21);
            labelHeight.TabIndex = 4;
            labelHeight.Text = "Длинна цветка";
            labelHeight.Click += labelHeight_Click;
            // 
            // comboBoxName
            // 
            comboBoxName.FormattingEnabled = true;
            comboBoxName.Items.AddRange(new object[] { "Розы", "Кактусы", "Архидеи", "Подсолнухи", "Грохострелы" });
            comboBoxName.Location = new Point(158, 40);
            comboBoxName.Name = "comboBoxName";
            comboBoxName.Size = new Size(139, 23);
            comboBoxName.TabIndex = 5;
            comboBoxName.SelectedIndexChanged += comboBoxName_SelectedIndexChanged;
            // 
            // comboBoxType
            // 
            comboBoxType.FormattingEnabled = true;
            comboBoxType.Items.AddRange(new object[] { "обычные", "необычные", "необычнообычные", "обычнонеобычные" });
            comboBoxType.Location = new Point(158, 71);
            comboBoxType.Name = "comboBoxType";
            comboBoxType.Size = new Size(139, 23);
            comboBoxType.TabIndex = 6;
            comboBoxType.SelectedIndexChanged += comboBoxType_SelectedIndexChanged;
            // 
            // comboBoxCountry
            // 
            comboBoxCountry.FormattingEnabled = true;
            comboBoxCountry.Items.AddRange(new object[] { "Россия", "Китай", "США", "Канада", "Мексика" });
            comboBoxCountry.Location = new Point(158, 135);
            comboBoxCountry.Name = "comboBoxCountry";
            comboBoxCountry.Size = new Size(139, 23);
            comboBoxCountry.TabIndex = 8;
            comboBoxCountry.SelectedIndexChanged += comboBoxCountry_SelectedIndexChanged;
            // 
            // comboBoxColor
            // 
            comboBoxColor.FormattingEnabled = true;
            comboBoxColor.Items.AddRange(new object[] { "красные", "зелёные", "фиолетовый", "аделаидные", "винные" });
            comboBoxColor.Location = new Point(158, 104);
            comboBoxColor.Name = "comboBoxColor";
            comboBoxColor.Size = new Size(139, 23);
            comboBoxColor.TabIndex = 7;
            comboBoxColor.SelectedIndexChanged += comboBoxColor_SelectedIndexChanged;
            // 
            // listBoxFlowers
            // 
            listBoxFlowers.FormattingEnabled = true;
            listBoxFlowers.ItemHeight = 15;
            listBoxFlowers.Location = new Point(303, 38);
            listBoxFlowers.Name = "listBoxFlowers";
            listBoxFlowers.Size = new Size(419, 184);
            listBoxFlowers.TabIndex = 10;
            listBoxFlowers.SelectedIndexChanged += listBoxFlowers_SelectedIndexChanged;
            // 
            // labelQuantity
            // 
            labelQuantity.AutoSize = true;
            labelQuantity.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelQuantity.Location = new Point(24, 190);
            labelQuantity.Name = "labelQuantity";
            labelQuantity.Size = new Size(101, 21);
            labelQuantity.TabIndex = 11;
            labelQuantity.Text = "Количество";
            // 
            // buttonCheckPrice
            // 
            buttonCheckPrice.Location = new Point(324, 262);
            buttonCheckPrice.Name = "buttonCheckPrice";
            buttonCheckPrice.Size = new Size(136, 49);
            buttonCheckPrice.TabIndex = 13;
            buttonCheckPrice.Text = "Узнать стоимость \r\nтовара в корзине";
            buttonCheckPrice.UseVisualStyleBackColor = true;
            buttonCheckPrice.Click += buttonCheckPrice_Click;
            // 
            // buttonClearList
            // 
            buttonClearList.Location = new Point(466, 262);
            buttonClearList.Name = "buttonClearList";
            buttonClearList.Size = new Size(136, 49);
            buttonClearList.TabIndex = 14;
            buttonClearList.Text = "Очистить корзину";
            buttonClearList.UseVisualStyleBackColor = true;
            buttonClearList.Click += buttonClearList_Click;
            // 
            // buttonWritePurshase
            // 
            buttonWritePurshase.Location = new Point(182, 262);
            buttonWritePurshase.Name = "buttonWritePurshase";
            buttonWritePurshase.Size = new Size(136, 49);
            buttonWritePurshase.TabIndex = 15;
            buttonWritePurshase.Text = "Внести товар в корзину";
            buttonWritePurshase.UseVisualStyleBackColor = true;
            buttonWritePurshase.Click += buttonWritePurshase_Click;
            // 
            // numericUpDownHeight
            // 
            numericUpDownHeight.Location = new Point(158, 164);
            numericUpDownHeight.Minimum = new decimal(new int[] { 5, 0, 0, 0 });
            numericUpDownHeight.Name = "numericUpDownHeight";
            numericUpDownHeight.Size = new Size(139, 23);
            numericUpDownHeight.TabIndex = 16;
            numericUpDownHeight.Value = new decimal(new int[] { 5, 0, 0, 0 });
            numericUpDownHeight.ValueChanged += numericUpDownHeight_ValueChanged;
            // 
            // numericUpDownQuantity
            // 
            numericUpDownQuantity.Location = new Point(158, 193);
            numericUpDownQuantity.Maximum = new decimal(new int[] { 50, 0, 0, 0 });
            numericUpDownQuantity.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDownQuantity.Name = "numericUpDownQuantity";
            numericUpDownQuantity.Size = new Size(139, 23);
            numericUpDownQuantity.TabIndex = 17;
            numericUpDownQuantity.Value = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDownQuantity.ValueChanged += numericUpDownQuantity_ValueChanged;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(numericUpDownQuantity);
            Controls.Add(numericUpDownHeight);
            Controls.Add(buttonWritePurshase);
            Controls.Add(buttonClearList);
            Controls.Add(buttonCheckPrice);
            Controls.Add(labelQuantity);
            Controls.Add(listBoxFlowers);
            Controls.Add(comboBoxCountry);
            Controls.Add(comboBoxColor);
            Controls.Add(comboBoxType);
            Controls.Add(comboBoxName);
            Controls.Add(labelHeight);
            Controls.Add(labelCountry);
            Controls.Add(labelColor);
            Controls.Add(labelType);
            Controls.Add(labelName);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDownHeight).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownQuantity).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelName;
        private Label labelType;
        private Label labelColor;
        private Label labelCountry;
        private Label labelHeight;
        private ComboBox comboBoxName;
        private ComboBox comboBoxType;
        private ComboBox comboBoxCountry;
        private ComboBox comboBoxColor;
        private ListBox listBoxFlowers;
        private Label labelQuantity;
        private Button buttonCheckPrice;
        private Button buttonClearList;
        private Button buttonWritePurshase;
        private NumericUpDown numericUpDownHeight;
        private NumericUpDown numericUpDownQuantity;
        private ContextMenuStrip contextMenuStrip1;
    }
}
